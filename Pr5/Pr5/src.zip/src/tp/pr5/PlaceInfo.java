package tp.pr5;

public interface PlaceInfo {

	java.lang.String getName();
	
	java.lang.String getDescription();
	
	boolean isSpaceship();
}
