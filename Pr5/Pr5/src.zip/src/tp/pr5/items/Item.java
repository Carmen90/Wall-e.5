package tp.pr5.items;

import tp.pr5.NavigationModule;
import tp.pr5.RobotEngine;

public abstract class Item implements Comparable <Item>{
	protected String id;
	protected java.lang.String description;
	protected int times;
	
	public Item(java.lang.String id, java.lang.String description){
		
		this.id=id;
		this.description= description;
		this.times = 0;
	}
	
	public abstract boolean canBeUsed();
	
	public abstract boolean use(RobotEngine r,
	          NavigationModule nav);
	
	public java.lang.String getId(){
		return this.id;
		
	}
	
	public java.lang.String toString(){
		return this.id + " " + this.description;
		
	}
	
	public java.lang.String getDescription(){
		return this.description;
		
	}
	
	/**
	 * Reimplementa el metodo equals de la clase Object
	 * Dos Items son iguales si su id es igual. Ignora may�sculas y min�sculas
	 * @param objeto con el que se compara
	 */
	@Override 
	public boolean equals (Object obj){
		return (this == obj) ||
			   (obj != null) && (this.getClass() == obj.getClass()) 
				             && this.id.equalsIgnoreCase(((Item) obj).id)|| 
			   (obj != null) && (this.id.getClass() == obj.getClass())
			   				 && this.id.equalsIgnoreCase((String)obj);

	}
	
	/**
	 * Reimplements the compareTo
	 * Devuelve un entero en funci�n de si son iguales o no. Devuelve 0 en caso de que sean iguales
	 * Ignora may�sculas y min�sculas
	 * @param obj  item a comparar
	 */
	@Override
	public int compareTo ( Item obj){
		  return this.id.compareToIgnoreCase(obj.id);	
	}
}
