package tp.pr5.items;

import tp.pr5.NavigationModule;
import tp.pr5.RobotEngine;

public class Garbage extends Item{
	private int recycledMaterial;
	private boolean usar;
	
	public Garbage(java.lang.String id,
		       java.lang.String description,
		       int recycledMaterial){
		super (id, description);
		this.times=1;
		this.recycledMaterial = recycledMaterial;
		this.usar = true;
	}

	public boolean canBeUsed(){
		return this.usar;
		
	}
	
	public boolean use(RobotEngine r,
	          NavigationModule nav){
		if (this.canBeUsed()){
			r.addRecycledMaterial(this.recycledMaterial);
			this.usar = false;
			this.times--;
			return true;
		}
		
		//Crear variable boolean para no usar 2 return?
		return false;
		
	}
	
	public java.lang.String toString(){
		return this.id + ": "+ this.description;
		
	}
	
}
