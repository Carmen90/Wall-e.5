package tp.pr5.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import tp.pr5.RobotEngine;

public class GUIController extends tp.pr5.Controller implements ActionListener, FocusListener{
	private RobotEngine robot;
	public GUIController(RobotEngine robot){
		this.robot = robot;
	}

	@Override
	public void registerEngineObserver() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void registerItemContainerObserver() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void registerRobotObserver() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startController() {
		// TODO Auto-generated method stub
		
	}
	
	//////////////////METODOS DEL ACTIONLISTENER Y EL FOCUSLISTENER

	@Override
	public void focusGained(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusLost(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
