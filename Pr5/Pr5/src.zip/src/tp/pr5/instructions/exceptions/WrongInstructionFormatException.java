package tp.pr5.instructions.exceptions;

@SuppressWarnings("serial")
public class WrongInstructionFormatException extends java.lang.Exception{
	public WrongInstructionFormatException(){
		
	}
	
	public WrongInstructionFormatException(java.lang.String arg0){
		
	}
	
	public WrongInstructionFormatException(java.lang.Throwable arg0){
		
	}
	
	public WrongInstructionFormatException(java.lang.String arg0,
            java.lang.Throwable arg1){
		
	}

}
