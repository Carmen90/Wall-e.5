package tp.pr5.instructions.exceptions;

public class InstructionExecutionException extends java.lang.Exception{

	public InstructionExecutionException(){
		
	}
	
	public InstructionExecutionException(java.lang.String arg0){
		
	}
	
	public InstructionExecutionException(java.lang.Throwable arg0){
		
	}
	
	public InstructionExecutionException(java.lang.String arg0,
            java.lang.Throwable arg1){
		
	}
}
