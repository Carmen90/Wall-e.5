package tp.pr5;

public class Observable <T> extends java.util.Observable{

}
