package tp.pr5;

import java.util.Iterator;

import tp.pr5.instructions.exceptions.InstructionExecutionException;
import tp.pr5.items.Item;
/**
 * Esta clase se encarga de las funciones de navegaci�n del robot.Contiene la ciudad donde el robot busca de
 * la basura, el lugar actual donde se encuentra el robot, la direcci�n actual del robot.Contiene los metodos
 *  para manejar los movimientos del robot y  para coger y soltar los items en el lugar donde se encuentra
 * @author Nerea Ram�rez y Carmen Acosta
 *
 */
public class NavigationModule extends tp.pr5.Observable<NavigationObserver> {
	private City city;
	private Direction direction;
	private Place initialPlace;
/**
 * constructora por defecto
 */
	public NavigationModule (){
		this.city = new City();
		this.direction = Direction.UNKNOWN;
		this.initialPlace = new Place();
	}
	/**
	 * Crea un navigationModule con el mapa de la ciudad y un lugarInicial dado
	 * @param aCity -el mapa de la ciudad
	 * @param initialPlace - el lugar inicial del robot.
	 */
	public NavigationModule(City aCity,
            Place initialPlace){
		this.city = aCity;
		this.initialPlace = initialPlace;
		this.direction = Direction.NORTH;
	}
	/**
	 * Mira si el robot ha llegado a la nave.
	 * @return - true si el lugar actual donde se encuentra el robot es la nave.
	 */
	public boolean atSpaceship(){
		return this.initialPlace.isSpaceship();
		
	}
	/**
	 * Actualiza la direcci�n actual de acuerdo con el rotaci�n que le pasan por par�metro.
	 * @param rotation
	 */
	public void rotate(Rotation rotation){
		this.direction = this.direction.rotate(rotation);
	}
	/**
	 * Este m�todo intenta mover al robot en la direcci�n actual en la que se encuentra.
	 * Si el movimiento no es posible porque no hay calle en esa direcci�n o la puerta est� cerrada entonces se lanza una excepci�n.
	 * Si no es as� entonces se actualiza el lugar de acuerdo con el movimiento
	 * @throws InstructionExecutionException
	 */
	public void move()
	          throws InstructionExecutionException{
		Street calle = this.getHeadingStreet();
		
		if(calle==null){
			throw new InstructionExecutionException("There's no street");
		}
		else{
			if(calle.isOpen()){
				this.initialPlace = calle.nextPlace(this.initialPlace);
			}
			else{
				throw new InstructionExecutionException( "The street is closed.");
			}			
		}	
	}
	/**
	 * Intenta coger un item del lugar actual donde se encuentra el robot con el id que se pasa por par�metro.
	 * Si la acci�n se puede hacer se borra el item del lugar actual.
	 * @param id
	 * @return -El item con identificador id si existe en el lugar sino devuelve null
	 */
	public Item pickItemFromCurrentPlace(java.lang.String id){
		Item item = null;
		if( this.initialPlace.existItem(id)){
			item = this.initialPlace.pickItem(id);
			Iterator <NavigationObserver> navOb = this.iterator();
			while (navOb.hasNext()){
				navOb.next().placeHasChanged(this.initialPlace);
			}
		}
		return item;
	}
	/**
	 * Suelta un item en el lugar actual donde se encuentra el robot.
	 * @param item- el nombre de item que se suelta
	 */
	public void dropItemAtCurrentPlace(Item item){
		if ( !this.initialPlace.existItem(item.getId())){
			this.initialPlace.addItem(item);
			Iterator <NavigationObserver> navOb = this.iterator();
			while (navOb.hasNext()){
				navOb.next().placeHasChanged(this.initialPlace);
			}
		}
	}
	/**
	 * Mira si hay un item con el id dado en el lugar. Lo �nico que hace es llamar al m�todo existItem():
	 * @param id
	 * @return - true si encuentra el item con ese id, sino devuelve false
	 */
	public boolean findItemAtCurrentPlace(java.lang.String id){
		return this.initialPlace.existItem(id);
		
	}
	/**
	 * Inicializa el lugar con los par�metros dados
	 * @param heading -Nueva direcci�n para el robot.
	 */
	public void initHeading(Direction heading){
		this.direction = heading;
		Iterator <NavigationObserver> navOb = this.iterator();
		while (navOb.hasNext()){
			navOb.next().headingChanged(this.direction);
		}
	}
	/**
	 * Proporciona a los observadores la informaci�n con el metodo toString() del lugar actual donde se encuentra el robot.
	 */
	public void scanCurrentPlace(){
		this.initialPlace.toString();
	}
	/**
	 * Devuelve la calle a la que esta mirando el robot llamado al metodo lookForStreet(Place, Direction).
	 * @return Si no hay calle devolver� null.
	 */
	public Street getHeadingStreet(){
		return this.city.lookForStreet( this.initialPlace, this.direction);
		
	}
	/**
	 * Devuelve la direccion donde mira el robot
	 * @return
	 */
	public Direction getCurrentHeading(){
		return this.direction;
		
	}
	/**
	 * Devuelve el lugar donde se encuentra el robot
	 * @return - initialPlace
	 */
	public Place getCurrentPlace(){
		return this.initialPlace;
		
	}
	
	
}
