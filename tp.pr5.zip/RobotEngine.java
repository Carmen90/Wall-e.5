/**
 * Est� lase representa al robot, controla sus movimientos procesando las instrucciones a trav�s de los controladores.
 * El robot se apaga, deja de fncionar cuando llega donde est� la nave, cuando se queda sin fuel o cuando recibe la instrucci�n de salir. 
 * Tambi�n se encarga de actualizar el fuel y el recycled material de acuerdo con las accionesque realiza en la ciudad.
 * Atributos: contiene un inventario(ItemContainer) donde guarda los items que  recoge de la ciudad; una direcci�n para saber hacia donde est� mirando; un booleano para saber cuando tiene que salirse;2 enteros para el fuel y el material reycled y un navigationModule.
 */
package tp.pr5;



import java.util.Iterator;

import tp.pr5.instructions.Instruction;
import tp.pr5.instructions.exceptions.InstructionExecutionException;
import tp.pr5.items.InventoryObserver;
import tp.pr5.items.ItemContainer;

public class RobotEngine extends tp.pr5.Observable<RobotEngineObserver>{
	private NavigationModule navega;
	private int fuel;
	private int recycledMaterial;
	private ItemContainer container;
	private Direction direction;
	private boolean quit = false;
	/**
	 * Constructora por defecto que inicializa los atributos 
	 */

	public RobotEngine (){
		this.fuel = 100;
		this.recycledMaterial = 0;
		this.container = new ItemContainer ();
		this.direction = Direction.NORTH;
		this.navega = new NavigationModule();
	}
	/**
	 * Constructora que crea el robot Engine en un  lugar inicial,frente a una direcci�n inicial y con una mapa de la ciudad.
	 * Inicialmente el robot no tiene ning�n art�culo o material reciclado, pero tiene una cantidad inicial de fuel de 100
	 */
	public RobotEngine(City map,
	           Place initialPlace,
	           Direction direction){
		this.navega = new NavigationModule ( map, initialPlace);
		this.recycledMaterial = 0;
		this.fuel = 100;
		this.container = new ItemContainer();
		this.direction = direction;
	}
/**
 * En este m�todo se ejecuta una instrucci�n. Antes de ejecutar la instrucci�n debe estar configurada con el contexto.
 * Se controla el final de la simulaci�n.Si la ejecuci�n lanza una excepci�n se imprimir� el mensaje correspondiente.
 * @param c -Instrucci�n que se quiere ejecutar.
 */
	public void communicateRobot(Instruction c){
		 c.configureContext(this,this.navega,this.container);
		 try{
			 c.execute();
		 }catch(InstructionExecutionException e){
				Iterator <RobotEngineObserver> robOb = this.iterator();
				while (robOb.hasNext()){
					robOb.next().raiseError(e.getMessage());
				}
			 
		 }
	}
	/**
	 * Aqu� se controla si el juego se ha acabado.Esto ocurre cuando el fuel es menor que 0, cuando se ha llegado donde est� la nave o cuando se ha llamado a la instrucci�n quit.
	 * @return- devuelve un booleano que indica si el juego ha finalizado(true) , false si no.
	 */
	public boolean isOver(){
		return this.fuel <= 0 || this.navega.getCurrentPlace().isSpaceship()|| this.quit  ;
		
	}
	/**
	 * Este m�todo incrementa el recycled material del robot
	 * @param weight
	 */
	public void addRecycledMaterial(int weight){
		this.recycledMaterial += weight;
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().robotUpdate(fuel, this.recycledMaterial);
		}
	}
	/**
	 * Incrementa el fuel y lo actualiza.
	 * @param fuel
	 */
	public void addFuel(int fuel){
		this.fuel += fuel;
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().robotUpdate(this.fuel, this.recycledMaterial);
		}
	}
	/**
	 * Devuelve el fuel
	 * @return
	 */
	public int getFuel(){
		return this.fuel;
	}
	/**
	 * Devuelve el recycled material
	 * @return
	 */
	public int getRecycledMaterial(){
		return this.recycledMaterial;
	}
	/**
	 * Pide al robotEngine informar a los observadores que la simulaci�n ha comenzado
	 */
	public void requestStart(){
		
		Iterator <NavigationObserver> navOb = this.navega.iterator();
		while ( navOb.hasNext()){
			navOb.next().initNavigationModule(this.navega.getCurrentPlace(), this.direction);
		}
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().robotUpdate(fuel, recycledMaterial);
		}
	}
	/**
	 * Se pide el final de la simulaci�n y se informa de ello al RobotEngineObserver  
	 */
	public void requestQuit(){
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while ( robOb.hasNext()){
			RobotEngineObserver aux = robOb.next();
			//aux.engineOff(this.navega.atSpaceship());//.communicationCompleted();
			aux.communicationCompleted();
		}
		this.quit = true;
	}
	/**
	 * Se pide al robotEnginela informaci�n sobre las instrucciones v�lidas.
	 */
	public void requestHelp(){
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().communicationHelp(Interpreter.interpreterHelp());
		}
	}
	/**
	 * Se pide al robotEngine informar sobre un error que se ha planteado
	 */
	public void requestError(java.lang.String msg){
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().raiseError(msg);
		}
	}
	/**
	 * Solicita al robot decir algo
	 * @param message  - el mensaje para decir
	 */
	public void saySomething(java.lang.String message){
		Iterator <RobotEngineObserver> robOb = this.iterator();
		while (robOb.hasNext()){
			robOb.next().robotSays(message);
		}
	}
	/**
	 * Aqui se a�ade al navigationModule un nuevo NavigationObserver
	 * @param robotObserver - El observador que desea registrarse
	 */
	public void addNavigationObserver(NavigationObserver robotObserver){
		this.navega.add(robotObserver);
	}
	/**
	 * Regitra un EngineObserver al modelo
	 * @param observer - El observador que desea registrarse
	 */
	public void addEngineObserver(RobotEngineObserver observer){
		this.add(observer);
	}
	/**
	 * Registra un ItemContainerObserver al modelo
	 * @param observer - El observador que desea registrarse
	 */
	public void addItemContainerObserver(InventoryObserver observer){
		this.container.add(observer);
	}

	public boolean isQuit() {
		return quit;
	}

}

