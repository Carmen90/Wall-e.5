package tp.pr5;

import java.util.ArrayList;

/**
 * Esta clase representa la ciudad por donde el robot pasea.
 * Tiene un unico atributo(cityMap) que interpreta un arrayList donde se encuentran todas las calles de la ciudad.
 *Aqui se podria a�adir una nueva clase, buscar si hay una calle dando una direcci�n y un lugar.
 * @author Nerea Ramirez y Carmen Acosta
 *
 */
public class City {
	private ArrayList<Street> cityMap;
	public City(){		
	}
	
	public City(Street[] cityMap){
		this.cityMap = new ArrayList <Street> ();
		
		for ( int i = 0; i < cityMap.length; i++){
			this.cityMap.add(cityMap[i]);
		}
	}

	/**
	 * El metodo lookForStreet se encarga de devolver la calle a la que se esta mirando desde el lugar y la direccion dada
	 * Si el arrayList cityMap no es nulo, no se ha llegado al final del arrayList y no hay una calle nula, se va recorriendo cityMap buscando la calle
	 *  que tiene la direcci�n y el lugar pasados por parametro hasta que se encuentre. 
	 * @param currentPlace -El lugar donde buscar la calle.
	 * @param currentHeading - La direcci�n donde se encuentra la calle.
	 * @return  Si encontrado==true devuelve la calle sino devolver� null.
	 */
	public Street lookForStreet(Place currentPlace,
            Direction currentHeading){
		
		int i = 0;
		Street calle = null;
		boolean enc = false;
		
		if (this.cityMap != null){
			while ( i < this.cityMap.size() && !enc && this.cityMap.get(i)!= null){
				if ( this.cityMap.get(i).comeOutFrom(currentPlace, currentHeading)){
					enc = true;
					calle = this.cityMap.get(i);
				}
				else{
					i++;
					
				}
			}
		}
		return calle;
		
	}
	/**
	 * A�ade una calle a la ciudad.
	 * @param street
	 */
	public void addStreet(Street street){
		this.cityMap.add(street);
	}

}
