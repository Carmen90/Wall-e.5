package tp.pr5;
/**
 * Clase abstracta que define las funcionalidad b�sica com�n de los 2 controladores que tenemos en la pr�ctica
 * @author Nerea Rsmirez y Carmen Acosta
 *
 */
public abstract class Controller {

	public abstract void registerEngineObserver();
	
	public abstract void registerItemContainerObserver();
	
	public abstract void registerRobotObserver();
	
	public abstract void startController();
}
